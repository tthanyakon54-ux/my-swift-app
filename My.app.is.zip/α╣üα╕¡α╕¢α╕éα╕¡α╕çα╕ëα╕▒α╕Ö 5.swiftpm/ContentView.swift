import SwiftUI

// MARK: - 1. DATA MODELS (อัปเดต: เพิ่ม Email/Password)

enum UserRole: String, CaseIterable, Identifiable {
    case student = "นักเรียน"
    case leader = "หัวหน้าห้อง"
    case teacher = "ครูที่ปรึกษา"
    var id: String { self.rawValue }
}

enum WasteType: String, CaseIterable, Identifiable {
    case plastic = "พลาสติก"
    case can = "กระป๋อง"
    case general = "ขยะทั่วไป"
    // ... (rest of WasteType struct remains the same)
    var id: String { self.rawValue }
    
    func calculatePoints(amount: Int) -> Int {
        switch self {
        case .plastic: return (amount / 15) * 5
        case .can: return (amount / 15) * 10
        case .general: return (amount / 20) * 10
        }
    }
    
    var unit: String {
        switch self {
        case .plastic: return "ขวด"
        case .can: return "กระป๋อง"
        case .general: return "ชิ้น"
        }
    }
    
    var ruleDescription: String {
        switch self {
        case .plastic: return "ขั้นต่ำ 15 ขวด (5 แต้ม)"
        case .can: return "ขั้นต่ำ 15 กป. (10 แต้ม)"
        case .general: return "ขั้นต่ำ 20 ชิ้น (10 แต้ม)"
        }
    }
}

struct Student: Identifiable, Codable {
    var id = UUID()
    var name: String
    var studentNumber: String
    var room: String
    var email: String // NEW
    var password: String // NEW (Simulated)
    var score: Int = 0 
    var totalLifetimeScore: Int = 0 
    var redeemedMoney: Int = 0
    var history: [HistoryLog] = []
    
    var numberInt: Int {
        return Int(studentNumber) ?? 9999
    }
}

struct HistoryLog: Identifiable, Codable {
    var id = UUID()
    var date: Date
    var description: String
    var scoreChange: Int
    var approver: String
    var redeemedMoney: Int?
}

struct PointRequest: Identifiable {
    var id = UUID()
    var studentId: UUID
    var studentName: String
    var wasteType: WasteType
    var amount: Int
    var calculatedPoints: Int
    var hasPhotoAttached: Bool
}

struct RedemptionRequest: Identifiable {
    var id = UUID()
    var studentId: UUID
    var studentName: String
    var availableScore: Int
    
    var possibleOptions: [Int] {
        var options: [Int] = []
        let maxRedeemable = (availableScore / 50) * 50
        var current = 50
        while current <= maxRedeemable {
            options.append(current)
            current += 50
        }
        return options
    }
}

// MARK: - 2. VIEW MODEL (อัปเดต: การ Login/Register)

class AppData: ObservableObject {
    @Published var students: [Student] = []
    @Published var pendingPointRequests: [PointRequest] = []
    @Published var pendingRedemptionRequests: [RedemptionRequest] = []
    
    @Published var isLoggedIn: Bool = false
    @Published var currentUserRole: UserRole? = nil
    @Published var currentStudentId: UUID? = nil
    
    // อัปเดต: รับ email และ password
    func registerStudent(name: String, number: String, room: String, email: String, password: String) {
        let newStudent = Student(name: name, studentNumber: number, room: room, email: email, password: password, score: 0, totalLifetimeScore: 0)
        students.append(newStudent)
    }
    
    // อัปเดต: Login ด้วย email/password
    func loginAsStudent(email: String, password: String) -> Bool {
        if let student = students.first(where: { $0.email.lowercased() == email.lowercased() && $0.password == password }) {
            self.currentStudentId = student.id
            self.currentUserRole = .student
            self.isLoggedIn = true
            return true
        }
        return false
    }
    
    func loginAsStaff(role: UserRole) {
        self.currentUserRole = role
        self.isLoggedIn = true
    }
    
    func logout() {
        self.isLoggedIn = false
        self.currentUserRole = nil
        self.currentStudentId = nil
    }
    
    // ... (rest of the logic remains the same)
    
    func approvePointRequest(request: PointRequest, isApproved: Bool) {
        if let index = students.firstIndex(where: { $0.id == request.studentId }), isApproved {
            students[index].score += request.calculatedPoints
            students[index].totalLifetimeScore += request.calculatedPoints
            
            let log = HistoryLog(date: Date(), description: "ส่ง: \(request.wasteType.rawValue) \(request.amount) \(request.wasteType.unit)", scoreChange: request.calculatedPoints, approver: "หัวหน้าห้อง", redeemedMoney: nil)
            students[index].history.append(log)
        }
        pendingPointRequests.removeAll(where: { $0.id == request.id })
    }
    
    func submitPointRequest(studentId: UUID, type: WasteType, amount: Int, photo: Bool) {
        guard let student = students.first(where: { $0.id == studentId }) else { return }
        let points = type.calculatePoints(amount: amount)
        let req = PointRequest(studentId: studentId, studentName: student.name, wasteType: type, amount: amount, calculatedPoints: points, hasPhotoAttached: photo)
        pendingPointRequests.append(req)
    }
    
    func submitRedemptionRequest(studentId: UUID) {
        guard let student = students.first(where: { $0.id == studentId }) else { return }
        if student.score >= 50 {
            let req = RedemptionRequest(studentId: studentId, studentName: student.name, availableScore: student.score)
            pendingRedemptionRequests.append(req)
        }
    }
    
    func approveRedemption(request: RedemptionRequest, pointsToRedeem: Int) {
        let moneyToReceive = (pointsToRedeem / 50) * 15
        
        if let index = students.firstIndex(where: { $0.id == request.studentId }) {
            guard students[index].score >= pointsToRedeem else { return }
            
            students[index].score -= pointsToRedeem 
            students[index].redeemedMoney += moneyToReceive
            
            let log = HistoryLog(date: Date(), description: "แลกเงินรางวัล: \(pointsToRedeem) แต้ม", scoreChange: -pointsToRedeem, approver: "ครู", redeemedMoney: moneyToReceive)
            students[index].history.append(log)
        }
        pendingRedemptionRequests.removeAll(where: { $0.id == request.id })
    }
}

// MARK: - 3. UI VIEWS

// --- Custom Wave Shape (สำหรับ UI สวยๆ) ---
struct WaveShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - 50))
        
        path.addQuadCurve(
            to: CGPoint(x: rect.minX, y: rect.maxY),
            control: CGPoint(x: rect.midX, y: rect.maxY - 100)
        )
        path.closeSubpath()
        return path
    }
}

struct ContentView: View {
    @StateObject var data = AppData()
    
    var body: some View {
        if data.isLoggedIn {
            MainAppView(data: data)
        } else {
            LoginView(data: data)
        }
    }
}

// --- 3.1 Login View (หน้าหลักเข้าสู่ระบบนักเรียนด้วย Email/Password) ---
struct LoginView: View {
    @ObservedObject var data: AppData
    @State private var emailInput = ""
    @State private var passwordInput = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Header
                ZStack {
                    WaveShape()
                        .fill(LinearGradient(gradient: Gradient(colors: [Color.green, Color.mint]), startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(height: 200)
                        .shadow(radius: 5)
                    
                    VStack {
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.white)
                            .padding(.top, 20)
                        Text("ขยะแลกแต้ม")
                            .font(.system(size: 45, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                        Text("เข้าสู่ระบบนักเรียน")
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.8))
                    }
                    .offset(y: -10)
                }
                
                // Login Form
                VStack(spacing: 20) {
                    Text("กรุณาเข้าสู่ระบบด้วยอีเมลและรหัสผ่าน")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    
                    TextField("อีเมล (Email)", text: $emailInput)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    SecureField("รหัสผ่าน (Password)", text: $passwordInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button("เข้าสู่ระบบ") {
                        if data.loginAsStudent(email: emailInput, password: passwordInput) == false {
                            alertMessage = "อีเมลหรือรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง"
                            showAlert = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 40)
                .padding(.top, 30)
                
                Spacer()
                
                // Navigation Links
                VStack(spacing: 10) {
                    NavigationLink(destination: RegistrationView(data: data)) {
                        Text("ลงทะเบียนนักเรียนใหม่")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    
                    NavigationLink(destination: StaffLoginView(data: data)) {
                        Text("เข้าสู่ระบบบุคลากร (ครู/หัวหน้า)")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.gray)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding()
            }
            .navigationTitle("")
            .navigationBarHidden(true)
            .alert(alertMessage, isPresented: $showAlert) {
                Button("ตกลง", role: .cancel) {}
            }
        }
    }
}

// --- 3.2 Registration View (หน้าลงทะเบียน - อัปเดตฟอร์ม) ---
struct RegistrationView: View {
    @ObservedObject var data: AppData
    @Environment(\.dismiss) var dismiss
    
    @State private var regName = ""
    @State private var regNumber = ""
    @State private var regRoom = ""
    @State private var regEmail = "" // NEW
    @State private var regPassword = "" // NEW
    @State private var showSuccessAlert = false
    
    var isFormValid: Bool {
        !regName.isEmpty && !regNumber.isEmpty && !regRoom.isEmpty && !regEmail.isEmpty && !regPassword.isEmpty
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 25) {
            Text("ลงทะเบียนนักเรียนใหม่ 📝")
                .font(.largeTitle)
                .bold()
                .padding(.bottom, 10)
            
            VStack(alignment: .leading, spacing: 15) {
                Text("ชื่อ-นามสกุล")
                TextField("เช่น สมคิด สุขใจ", text: $regName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("ชั้น/ห้อง")
                TextField("เช่น ม.1/1", text: $regRoom)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("เลขที่")
                TextField("ใส่เฉพาะตัวเลข", text: $regNumber)
                    .keyboardType(.numberPad)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Divider()
                
                Text("อีเมล (ใช้สำหรับเข้าสู่ระบบ)")
                TextField("example@school.ac.th", text: $regEmail) // NEW
                    .keyboardType(.emailAddress)
                    .autocapitalization(.none)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Text("รหัสผ่าน")
                SecureField("กำหนดรหัสผ่าน", text: $regPassword) // NEW
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            
            Button("ยืนยันลงทะเบียนและกลับหน้าเข้าสู่ระบบ") {
                if isFormValid {
                    data.registerStudent(name: regName, number: regNumber, room: regRoom, email: regEmail, password: regPassword)
                    showSuccessAlert = true
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
            .disabled(!isFormValid)
            .frame(maxWidth: .infinity)
            
            Spacer()
        }
        .padding()
        .navigationTitle("ลงทะเบียน")
        .alert("ลงทะเบียนสำเร็จ", isPresented: $showSuccessAlert) {
            Button("ตกลง", role: .cancel) {
                dismiss() // กลับไปหน้า LoginView
            }
        } message: {
            Text("คุณ \(regName) ถูกเพิ่มในระบบแล้ว\nโปรดใช้อีเมลและรหัสผ่านที่ตั้งไว้เพื่อเข้าสู่ระบบ")
        }
    }
}

// --- 3.3 Staff Login View (หน้าเข้าสู่ระบบบุคลากร) ---
struct StaffLoginView: View {
    @ObservedObject var data: AppData
    @State private var pinCode = ""
    @State private var showAlert = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("เข้าสู่ระบบบุคลากร")
                .font(.largeTitle)
                .bold()
            
            Text("กรุณาใส่รหัสผ่านเพื่อเข้าสู่ระบบ หัวหน้าห้อง/ครู")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            SecureField("รหัสผ่าน", text: $pinCode)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding(.horizontal, 50)
            
            HStack(spacing: 20) {
                Button("เข้าสู่ระบบ: หัวหน้าห้อง") {
                    if pinCode == "1234" { data.loginAsStaff(role: .leader) }
                    else { showAlert = true }
                }
                .buttonStyle(.bordered)
                
                Button("เข้าสู่ระบบ: ครู") {
                    if pinCode == "1234" { data.loginAsStaff(role: .teacher) }
                    else { showAlert = true }
                }
                .buttonStyle(.borderedProminent)
            }
            Spacer()
        }
        .padding(.top, 50)
        .navigationTitle("บุคลากร")
        .alert(isPresented: $showAlert) {
            Alert(title: Text("ผิดพลาด"), message: Text("รหัสผ่านไม่ถูกต้อง"), dismissButton: .default(Text("ลองใหม่")))
        }
    }
}


// --- Main App Flow, Dashboards, and Subviews (เหมือนเดิม) ---

struct MainAppView: View {
    @ObservedObject var data: AppData
    var body: some View {
        VStack {
            if data.currentUserRole == .student {
                StudentDashboard(data: data)
            } else if data.currentUserRole == .leader {
                LeaderDashboard(data: data)
            } else if data.currentUserRole == .teacher {
                TeacherDashboard(data: data)
            }
        }
        .navigationTitle(data.currentUserRole?.rawValue ?? "")
        .navigationBarItems(trailing: Button("ออกจากระบบ") {
            data.logout()
        })
    }
}

struct StudentDashboard: View {
    @ObservedObject var data: AppData
    @State private var selectedWaste: WasteType = .plastic
    @State private var amountString: String = ""
    @State private var showMessage = false
    @State private var message = ""
    @State private var photoAttached: Bool = false
    
    var currentUser: Student? {
        data.students.first(where: { $0.id == data.currentStudentId })
    }
    
    var isSubmittable: Bool {
        return Int(amountString) ?? 0 > 0 && photoAttached
    }
    
    var body: some View {
        ScrollView {
            if let user = currentUser {
                VStack(spacing: 25) {
                    // Score Card
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(LinearGradient(gradient: Gradient(colors: [.green, .mint]), startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(height: 150)
                            .shadow(radius: 5)
                        
                        VStack {
                            Text(user.name).font(.headline).foregroundColor(.white)
                            Text("คะแนนสะสมตลอดชีพ (Leaderboard): \(user.totalLifetimeScore) แต้ม")
                                .font(.caption)
                                .foregroundColor(.yellow)
                            Text("\(user.score)").font(.system(size: 60, weight: .bold)).foregroundColor(.white)
                            Text("คะแนนปัจจุบัน (ใช้แลกเงิน)").foregroundColor(.white.opacity(0.8))
                        }
                    }
                    .padding(.horizontal)
                    
                    // Input Form
                    VStack(alignment: .leading, spacing: 15) {
                        Text("ส่งขยะเพิ่มแต้ม").font(.title3).bold()
                        
                        Picker("ประเภท", selection: $selectedWaste) {
                            ForEach(WasteType.allCases) { type in
                                Text(type.rawValue).tag(type)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        
                        Text(selectedWaste.ruleDescription).font(.caption).foregroundColor(.red)
                        
                        HStack {
                            Text("จำนวน:")
                            TextField("0", text: $amountString)
                                .keyboardType(.numberPad)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .frame(width: 100)
                            Text(selectedWaste.unit)
                            Spacer()
                        }
                        
                        // ระบบแนบรูปภาพ (จำลอง)
                        Button(action: {
                            self.photoAttached.toggle()
                        }) {
                            HStack {
                                Image(systemName: photoAttached ? "photo.fill" : "photo.on.rectangle.angled")
                                Text(photoAttached ? "แนบรูปภาพแล้ว ✅ (แตะเพื่อยกเลิก)" : "📸 แนบรูปภาพขยะ (เพื่อความสุจริต)")
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(photoAttached ? Color.blue.opacity(0.1) : Color.gray.opacity(0.1))
                            .cornerRadius(5)
                            .foregroundColor(photoAttached ? .blue : .primary)
                        }
                        
                        // ปุ่มส่ง
                        Button("ส่งคำขอ") {
                            if let amount = Int(amountString), amount > 0 && photoAttached {
                                let points = selectedWaste.calculatePoints(amount: amount)
                                if points > 0 {
                                    data.submitPointRequest(studentId: user.id, type: selectedWaste, amount: amount, photo: photoAttached)
                                    message = "ส่งคำขอเรียบร้อย รอหัวหน้าอนุมัติ"
                                    amountString = ""; photoAttached = false
                                } else {
                                    message = "จำนวนน้อยกว่าเกณฑ์ (ได้ 0 แต้ม)"
                                }
                            } else {
                                message = "กรุณากรอกตัวเลขและแนบรูปภาพให้ถูกต้อง"
                            }
                            showMessage = true
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(!isSubmittable)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(color: .black.opacity(0.05), radius: 5)
                    .padding(.horizontal)
                    
                    // แลกรางวัล
                    Button(action: {
                        if user.score >= 50 {
                            data.submitRedemptionRequest(studentId: user.id)
                            message = "ส่งคำขอแลกเงินแล้ว รอครูอนุมัติ"
                            showMessage = true
                        }
                    }) {
                        HStack {
                            Image(systemName: "gift.fill")
                            Text("แลกรางวัล (ขั้นต่ำ 50 แต้ม)")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(user.score >= 50 ? Color.blue : Color.gray.opacity(0.5))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(user.score < 50)
                    .padding(.horizontal)
                    
                    // ประวัติ
                    VStack(alignment: .leading) {
                        Text("📜 ประวัติล่าสุด").font(.headline).padding(.leading)
                        if user.history.isEmpty {
                            Text("- ยังไม่มีประวัติ -").frame(maxWidth: .infinity).foregroundColor(.gray).padding()
                        } else {
                            ForEach(user.history.reversed().prefix(5)) { log in
                                HStack {
                                    Text(log.description).font(.subheadline)
                                    Spacer()
                                    if let money = log.redeemedMoney {
                                        Text("เงิน: \(money) บาท")
                                            .foregroundColor(.purple)
                                            .bold()
                                    } else {
                                        Text("\(log.scoreChange > 0 ? "+" : "")\(log.scoreChange) แต้ม")
                                            .bold()
                                            .foregroundColor(log.scoreChange > 0 ? .green : .red)
                                    }
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(8)
                                .padding(.horizontal)
                            }
                        }
                    }
                }
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
        .alert(isPresented: $showMessage) {
            Alert(title: Text("แจ้งเตือน"), message: Text(message), dismissButton: .default(Text("ตกลง")))
        }
    }
}

struct LeaderDashboard: View {
    @ObservedObject var data: AppData
    
    var body: some View {
        List {
            Section(header: Text("คำขอรออนุมัติ (\(data.pendingPointRequests.count))")) {
                if data.pendingPointRequests.isEmpty {
                    Text("ไม่มีคำขอใหม่").foregroundColor(.gray)
                }
                ForEach(data.pendingPointRequests) { req in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(req.studentName).bold()
                            Text("\(req.wasteType.rawValue) \(req.amount) \(req.wasteType.unit)")
                                .font(.subheadline)
                            HStack {
                                Image(systemName: req.hasPhotoAttached ? "checkmark.circle.fill" : "xmark.circle.fill")
                                    .foregroundColor(req.hasPhotoAttached ? .green : .red)
                                Text(req.hasPhotoAttached ? "มีรูปภาพ" : "ไม่มีรูปภาพ")
                            }.font(.caption)
                        }
                        Spacer()
                        Text("+\(req.calculatedPoints)").foregroundColor(.green).bold()
                        
                        Button("❌") { data.approvePointRequest(request: req, isApproved: false) }
                            .buttonStyle(.borderless)
                        Button("✅") { data.approvePointRequest(request: req, isApproved: true) }
                            .buttonStyle(.borderless)
                    }
                }
            }
            
            Section(header: Text("รายชื่อเพื่อนในห้อง (เรียงตามเลขที่)")) {
                if data.students.isEmpty {
                    Text("ยังไม่มีรายชื่อนักเรียน").foregroundColor(.gray)
                }
                ForEach(data.students.sorted { $0.numberInt < $1.numberInt }) { student in
                    HStack {
                        Text(student.studentNumber).frame(width: 30).foregroundColor(.gray)
                        Text(student.name)
                        Spacer()
                        Text("\(student.score)").bold().foregroundColor(.blue)
                    }
                }
            }
        }
    }
}

struct TeacherDashboard: View {
    @ObservedObject var data: AppData
    
    var body: some View {
        List {
            Section(header: Text("คำขอแลกรางวัล (\(data.pendingRedemptionRequests.count))")) {
                if data.pendingRedemptionRequests.isEmpty {
                    Text("ไม่มีคำขอ").foregroundColor(.gray)
                }
                ForEach(data.pendingRedemptionRequests) { req in
                    RedemptionApprovalRow(data: data, request: req)
                }
            }
            
            Section(header: Text("🏆 Leaderboard (คะแนนสะสมตลอดชีพ)")) {
                if data.students.isEmpty {
                    Text("ยังไม่มีข้อมูล").foregroundColor(.gray)
                } else {
                    ForEach(Array(data.students.sorted(by: { $0.totalLifetimeScore > $1.totalLifetimeScore }).enumerated()), id: \.element.id) { index, student in
                        HStack {
                            Text("#\(index + 1)")
                                .font(.headline)
                                .foregroundColor(index == 0 ? .orange : .primary)
                                .frame(width: 40)
                            
                            VStack(alignment: .leading) {
                                Text(student.name).bold()
                                Text("เลขที่ \(student.studentNumber)")
                                    .font(.caption).foregroundColor(.gray)
                            }
                            Spacer()
                            Text("\(student.totalLifetimeScore)")
                                .font(.title3)
                                .bold()
                                .foregroundColor(.blue)
                        }
                    }
                }
            }
        }
    }
}

struct RedemptionApprovalRow: View {
    @ObservedObject var data: AppData
    var request: RedemptionRequest
    @State private var selectedPoints: Int
    
    init(data: AppData, request: RedemptionRequest) {
        self.data = data
        self.request = request
        _selectedPoints = State(initialValue: request.possibleOptions.last ?? 0)
    }
    
    var moneyToReceive: Int {
        return (selectedPoints / 50) * 15
    }
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Text(request.studentName).bold()
                Spacer()
                Text("คะแนนที่มี: \(request.availableScore)")
                    .font(.caption)
            }
            
            if request.possibleOptions.isEmpty {
                Text("❌ คะแนนไม่พอแลก (ต่ำกว่า 50 แต้ม)").foregroundColor(.red)
            } else {
                HStack {
                    Text("อนุมัติแลก:")
                    Picker("แต้ม", selection: $selectedPoints) {
                        ForEach(request.possibleOptions, id: \.self) { pts in
                            Text("\(pts) แต้ม").tag(pts)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    
                    Text("ได้เงิน \(moneyToReceive) บาท")
                        .foregroundColor(.purple)
                        .bold()
                    
                    Spacer()
                    
                    Button("อนุมัติ") {
                        data.approveRedemption(request: request, pointsToRedeem: selectedPoints)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                }
            }
        }
    }
}


